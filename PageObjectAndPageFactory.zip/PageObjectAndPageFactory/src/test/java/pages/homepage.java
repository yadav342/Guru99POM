package pages;
import org.openqa.selenium.By;
 import org.openqa.selenium.WebDriver;

public class homepage {

    WebDriver driver;

    By homePageUserName = By.xpath("//table//tr[@class='heading3']");
    public  By NewCustomerbtn = By.xpath("//a[normalize-space()='New Customer']");
    public By CustomerName = By.xpath("//input[@name='name']");
    public By Gender = By.xpath("//tbody/tr[5]/td[2]");
    public By DateofBirth = By.xpath("//tbody/tr[5]/td[2]");
    public By Address = By.xpath("//textarea[@name='addr']");
    public By City = By.xpath("//input[@name='city']");
    public By State = By.xpath("//input[@name='state']");
    public By Pin = By.xpath("//input[@name='pinno']");
    public By MobileNumber = By.xpath("//input[@name='telephoneno']");
    public By Email = By.xpath("//input[@name='emailid']");
    public By Password = By.xpath("//input[@name='password']");
    public By Submit = By.xpath("//input[@name='sub']");


    public homepage(WebDriver driver){

        this.driver = driver;

    }

    //Get the User name from Home Page

    public String getHomePageDashboardUserName(){

        return    driver.findElement(homePageUserName).getText();

    }

    public void ClickNewCustomerbtn(){

        driver.findElement(NewCustomerbtn).click();
    }

    public void fillform(){
        driver.findElement(CustomerName).sendKeys("Sudhkar");
        driver.findElement(Gender).click();
        driver.findElement(DateofBirth).sendKeys("15021989");
        driver.findElement(Address).sendKeys("Rajmarge");
        driver.findElement(City).sendKeys("Delhi");
        driver.findElement(State).sendKeys("UP");
        driver.findElement(Pin).sendKeys("533124");
        driver.findElement(MobileNumber).sendKeys("2343453456");
        driver.findElement(Email).sendKeys("Test123@gmail.com");
        driver.findElement(Password).sendKeys("Test123");
        driver.findElement(Submit).click();

    }



}