package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login_selenium {
    WebDriver driver;

    loginPageFactory abc;
    public By user99GuruName = By.name("uid");
    public By password99Guru = By.name("password");
    public By titleText =By.className("barone");
    public By login = By.name("btnLogin");
    public By LoginPageContent = By.xpath("//span[normalize-space()='Steps To Generate Access']");

    public Login_selenium(WebDriver Driver){
        this.driver = Driver;
    }

    //Set user name in textbox

    public String ValidateStepsToGenerate(){
        return driver.findElement(LoginPageContent).getText();

    }

    public void setUserName(String strUserName){

        driver.findElement(user99GuruName).sendKeys(strUserName);

    }

    //Set password in password textbox

    public void setPassword(String strPassword){

        driver.findElement(password99Guru).sendKeys(strPassword);

    }
    //Click on login button
    public void clickLogin(){

        driver.findElement(login).click();

    }

    public String getLoginTitle() {

        return  driver.findElement(titleText).getText();
    }

     public void loginToGuru99(String strUserName,String strPasword){

        this.setUserName(strUserName);
        this.setPassword(strPasword);
        this.clickLogin();

    }

}