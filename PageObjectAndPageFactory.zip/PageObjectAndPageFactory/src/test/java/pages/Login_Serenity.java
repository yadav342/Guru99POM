package pages;

import net.serenitybdd.core.pages.PageComponent;
import net.serenitybdd.core.pages.WebElementFacade;

import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

@DefaultUrl("https://demo.guru99.com/V4/")
public class Login_Serenity extends PageComponent {
    @FindBy(name="uid")
    private WebElementFacade user99GuruName;
    @FindBy(name="password")
    private WebElementFacade password99Guru;
    @FindBy(className="barone")
    private WebElementFacade titleText;
    @FindBy(name="btnLogin")
    private WebElementFacade login;

       public void loginToGuru99(String strUserName,String strPasword){

        $(user99GuruName).sendKeys(strUserName);

        $(password99Guru).sendKeys(strPasword);
        $(login).click();
    }
    public String getLoginTitle(){

           return    titleText.getText();
    }


}
