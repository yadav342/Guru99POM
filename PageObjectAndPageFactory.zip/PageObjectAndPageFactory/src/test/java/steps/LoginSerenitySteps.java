package steps;

import com.sun.org.glassfish.gmbal.Description;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Title;
import org.junit.Assert;
import pages.Login_Serenity;

public class LoginSerenitySteps {

    Login_Serenity login;

   // @Title("This is for Launching the URL in Browser")
    @Description("Verify Browser Launched")
    @Step
    public void isOnLoginPage(){
        login.open();
    }

   // @Title("Enter UserName and Password and Click on Login Button")
    @Description("Login As User")
    @Step
    public void loginAsUser(){

        login.loginToGuru99("mgr123", "mgr!23");

       // login.loginToGuru99("mgr123", "mgr!23");
    }

   // @Title("Verify User is Logged in Successfully")
    @Description("Verify Login As User")
    @Step
    public void userShouldBeLogin(){
    //Assert.assertTrue(login.getLoginTitle().toLowerCase().contains("manger id : mgr123"));
    Assert.assertEquals(login.getLoginTitle(),"Guru99 Bank");
    }
}
