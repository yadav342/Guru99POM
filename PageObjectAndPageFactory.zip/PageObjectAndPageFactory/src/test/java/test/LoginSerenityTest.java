package test;

import net.serenitybdd.core.steps.UIInteractions;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import org.junit.Test;
import org.junit.runner.RunWith;
import steps.LoginSerenitySteps;
@RunWith(SerenityRunner.class)
public class LoginSerenityTest extends UIInteractions {

   @Steps
    LoginSerenitySteps LoginpageStep;

   @Test
    public void AppLoginTest(){
        LoginpageStep.isOnLoginPage();
       LoginpageStep.loginAsUser();
        LoginpageStep.userShouldBeLogin();

    }
}
