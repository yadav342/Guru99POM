package test;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import pages.Login_selenium;
import pages.homepage;
import pages.loginPageFactory;

public class HomePageTest {
    String driverPath = "D:\\Vikram\\chromedriver.exe";
    WebDriver driver;
    // Login objLogin;
    loginPageFactory factoryLogin;
    homepage objHomePage = new homepage(driver);
LoginTest logintest;

   // HomePageTest hometest = new HomePageTest();

    @Before
    public void setup() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver",driverPath);
        driver = new ChromeDriver();
        driver.get("https://demo.guru99.com/V4/");
        Thread.sleep(1000);
    }

    @Test
    public void verifyloginTitle() throws InterruptedException {
        Login_selenium loginobj = new Login_selenium(driver);
        String title = loginobj.getLoginTitle();
        System.out.println("Title of the page "+ title);
        Assert.assertEquals(title,"Guru99 Bank");
    }

    @Test
    public void verifyHomePage() {
        Login_selenium loginobj = new Login_selenium(driver);
        loginobj.loginToGuru99("mgr123", "mgr!23");
        homepage objHomePage = new homepage(driver);
       String homepage= objHomePage.getHomePageDashboardUserName();
       System.out.println(homepage);
    Assert.assertEquals(homepage,"mgr123");
    }

    @Test
    public void ClickNewCustomer() throws InterruptedException {
        Login_selenium loginobj = new Login_selenium(driver);
        loginobj.loginToGuru99("mgr123", "mgr!23");
        homepage objHomePage = new homepage(driver);
        objHomePage.getHomePageDashboardUserName();
        objHomePage.ClickNewCustomerbtn();
        Thread.sleep(5000);

    }

    @Test
    public void FillNewCustomerForm() throws InterruptedException {
        Login_selenium loginobj = new Login_selenium(driver);
        loginobj.loginToGuru99("mgr123", "mgr!23");
        homepage objHomePage = new homepage(driver);
        objHomePage.getHomePageDashboardUserName();
        objHomePage.ClickNewCustomerbtn();
        Thread.sleep(5000);
        objHomePage.fillform();


    }

    @After
    public void Teardown (){

        driver.close();
    }


}
