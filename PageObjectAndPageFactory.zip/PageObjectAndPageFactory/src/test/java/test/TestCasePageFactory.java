package test;

import org.junit.After;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.HomePageFactory;
import pages.Login_selenium;
import pages.loginPageFactory;

public class TestCasePageFactory {

    String driverPath = "D:\\chromedriver.exe";
    WebDriver driver;
    loginPageFactory objLogin;
    Login_selenium NormalPage;
    HomePageFactory objHomePage;

    @BeforeTest
    public void setup() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver",driverPath);
        driver = new ChromeDriver();
        driver.get("https://demo.guru99.com/V4/");
        Thread.sleep(1000);
    }

    /**

     * This test go to http://demo.guru99.com/V4/

     * Verify login page title as guru99 bank

     * Login to application

     * Verify the home page using Dashboard message

     */

    @Test

    public void test_Home_Page_Appear_Correct(){

        //Create Login Page object

        objLogin = new loginPageFactory(driver);

        //Verify login page title

        String loginPageTitle = objLogin.getLoginTitle();

        Assert.assertTrue(loginPageTitle.toLowerCase().contains("guru99 bank"));

        //login to application

        objLogin.loginToGuru99("mgr123", "mgr!23");

        // go the next page

        objHomePage = new HomePageFactory(driver);

        //Verify home page

        Assert.assertTrue(objHomePage.getHomePageDashboardUserName().toLowerCase().contains("manger id : mgr123"));

    }

    @AfterTest
    public void TearDown(){

        driver.close();
    }

}