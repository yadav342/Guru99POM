package test;
        import org.junit.After;
        import org.junit.Before;
        import org.junit.Test;
        import org.openqa.selenium.WebDriver;
        import org.openqa.selenium.chrome.ChromeDriver;
        import org.testng.Assert;
        import pages.Login_selenium;
        import pages.homepage;
        import pages.loginPageFactory;


public class LoginTest {
    String driverPath = "D:\\chromedriver.exe";
    WebDriver Chromedriver;
//    Login objLogin;
    loginPageFactory factoryLogin;
   homepage objHomePage;


    @Before
    public void setup() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver",driverPath);
        Chromedriver = new ChromeDriver();
        Chromedriver.get("https://demo.guru99.com/V4/");
        Thread.sleep(1000);
    }

    @Test
    public void test_Home_Page_Appear_Correct() throws InterruptedException {

        //Create Login Page object
        Login_selenium objLogin = new Login_selenium(Chromedriver);
        //Verify login page title
        String loginPageTitle = objLogin.getLoginTitle();

        System.out.println("LoginTitle "+loginPageTitle);
        Assert.assertTrue(loginPageTitle.toLowerCase().contains("guru99 bank"));
        //Assert.assertEquals(loginPageTitle,"guru99 bank");
        //login to application
        objLogin.loginToGuru99("mgr123", "mgr!23");
        // go the next page
        objHomePage = new homepage(Chromedriver);
        //Verify home page
        Assert.assertTrue(objHomePage.getHomePageDashboardUserName().toLowerCase().contains("manger id : mgr123"));

       objHomePage.ClickNewCustomerbtn();


    }





    @Test
    public void Test_login_Page_Content(){
        Login_selenium objLogin = new Login_selenium(Chromedriver);
        String LoginContent = objLogin.ValidateStepsToGenerate();
        System.out.println(LoginContent);
        Assert.assertEquals(LoginContent,"Step To Generate Access");
        System.out.println("Test_login_Page_Content Test Case Passed");

    }


    @After
    public void TearDown(){
        Chromedriver.close();
    }


   @Test
    public void JunitTestCase(){

        System.out.println("This is Junit Test case");
    }

}